# 依赖
此项目由于使用了match case语法，需要安装python 3.10.0 版本及以上