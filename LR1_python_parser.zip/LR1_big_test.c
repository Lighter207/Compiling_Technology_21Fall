main {
    i=2;
    while(i<=100)
    {
        sum = sum+i;
        i = i+2;
    }
}